python3 traindata.py
sleep 1
python3 trans.py